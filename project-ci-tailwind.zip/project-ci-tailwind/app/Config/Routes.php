<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/admin', 'adminController::index');
$routes->get('/datapegawai', 'adminController::dataPegawai');
$routes->get('/signup', 'adminController::daftarPegawai');