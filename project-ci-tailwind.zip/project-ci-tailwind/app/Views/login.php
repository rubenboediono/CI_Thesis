<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= base_url() ?>css/style.css?v=1.0">
    <title>Halaman Login</title>
</head>

<body>
    <div class="bg-gray-100">

        <div class="flex items-center justify-center h-screen">

            <div class="bg-white p-8 rounded shadow-md w-96">
                <h1 class="text-3xl font-bold mb-6">Login</h1>
                <form action="" method="post">
                    <div class="mb-4">
                        <label for="nip" class="block text-gray-700">NIP</label>
                        <input type="text" id="nip" name="nip" class="w-full border-2 border-gray-300 p-2 rounded" required>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="block text-gray-700">Password:</label>
                        <input type="password" id="password" name="password" class="w-full border-2 border-gray-300 p-2 rounded" required>
                    </div>


                    <a href="admin">
                        <button type="submit" class="bg-[#4318FF] text-white p-2 rounded">Login</button>
                    </a>

                </form>

                <a href="admin">
                    <button class="bg-[#4318FF] text-white p-2 rounded">Login Tes</button>
                </a>

                <a href="signup">
                    <button class="bg-[#4318FF] text-white p-2 rounded">Daftar</button>
                    </a>

            </div>
        </div>

    </div>
</body>

</html>