<?php

namespace App\Controllers;

class adminController extends BaseController
{
    public function index()
    {

        echo view('/layouts/header');
        echo view('/admin/dashboardAdmin');
    }

    public function dataPegawai()
    {
        echo view('/layouts/header');
        echo view('/admin/dataPegawai');
       
    }

    public function daftarPegawai()
    {
        echo view('/layouts/header');
        echo view('/admin/daftarPegawai');
    }


}
